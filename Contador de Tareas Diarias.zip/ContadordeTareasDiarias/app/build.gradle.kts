plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
    alias(libs.plugins.kotlin.compose)
}

android {
    namespace = "com.example.contadordetareasdiarias"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.example.contadordetareasdiarias"
        minSdk = 26 // Actualizado a 26 para admitir LocalDate y otras características modernas
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_11
        targetCompatibility = JavaVersion.VERSION_11
    }

    kotlinOptions {
        jvmTarget = "11"
    }

    buildFeatures {
        compose = true
        buildConfig = true // Generación de BuildConfig activada
    }

    composeOptions {
        kotlinCompilerExtensionVersion = "1.5.4" // Versión específica para Compose
    }
}

dependencies {
    // Core AndroidX
    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.lifecycle.runtime.ktx)

    // Compose UI
    implementation(libs.androidx.activity.compose)
    implementation(platform(libs.androidx.compose.bom)) // BOM para versiones de Compose
    implementation(libs.androidx.ui) // Compose UI
    implementation(libs.androidx.ui.graphics) // Compose Graphics
    implementation(libs.androidx.ui.tooling.preview) // Compose Tooling Preview
    implementation(libs.androidx.material3) // Material 3

    // Jetpack Navigation para Compose
    implementation("androidx.navigation:navigation-compose:2.7.4") // Navegación en Compose

    // Animaciones en Compose
    implementation("androidx.compose.animation:animation:1.5.4") // Animaciones

    // DatePicker y otras utilidades de material
    implementation("androidx.compose.material3:material3:1.1.2") // Material 3 con componentes avanzados
    implementation("androidx.compose.material3:material3-window-size-class:1.1.2") // Tamaños de ventana

    // Pruebas unitarias
    testImplementation(libs.junit)

    // Pruebas instrumentadas
    androidTestImplementation(libs.androidx.junit)
    androidTestImplementation(libs.androidx.espresso.core)
    androidTestImplementation(platform(libs.androidx.compose.bom)) // BOM para pruebas de Compose
    androidTestImplementation(libs.androidx.ui.test.junit4) // Pruebas de UI con JUnit 4

    // Herramientas de desarrollo
    debugImplementation(libs.androidx.ui.tooling) // Compose Tooling
    debugImplementation(libs.androidx.ui.test.manifest) // Pruebas de UI en modo debug
}