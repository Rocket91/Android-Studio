package com.example.app

import android.content.res.Configuration
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.example.app.ui.theme.AppTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            AppTheme {
                PersonalData(name = "Luis Diego")
            }
        }
    }
}

@Composable
fun PersonalData(name: String) {
    Column(
        modifier = Modifier.padding(10.dp).fillMaxWidth(),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Image(
            painter = painterResource(R.drawable.jetpack),
            contentDescription = "Esta es una imagen de jetpack",
            modifier = Modifier.height(200.dp)
        )
        Text(text = "Mi nombre es $name", style = MaterialTheme.typography.headlineLarge)
        Text(text = "Luis Diego")
        Text(text = "Estoy aprendiendo JetPack Compose")

        // Lista de elementos
        val items = listOf("Aprendiendo", "JetPack Compose", "Curso", "Programación Android", "Hola, Mundo")
        ItemList(items = items)
    }
}

@Composable
fun ItemList(items: List<String>) {
    LazyColumn(modifier = Modifier.fillMaxSize()) {
        items(items.size) { index ->
            MyComponent(itemText = items[index])
        }
    }
}
 // Animacion
@Composable
fun MyComponent(itemText: String) {
    Row(
        modifier = Modifier
            .background(MaterialTheme.colorScheme.background)
            .padding(8.dp)
            .fillMaxWidth()
            .animateContentSize()
    ) {
        MyImage()
        Spacer(modifier = Modifier.width(16.dp))
        MyTexts(itemText = itemText)
    }
}

@Composable
fun MyImage() {
    Image(
        painter = painterResource(R.drawable.jetpack),
        contentDescription = "Este es mi logo",
        modifier = Modifier
            .clip(CircleShape)
            .background(MaterialTheme.colorScheme.primary)
            .size(80.dp)
    )
}

@Composable
fun MyTexts(itemText: String) {
    Column(modifier = Modifier.padding(start = 8.dp)) {
        MyText(
            text = itemText,
            color = MaterialTheme.colorScheme.primary,
            style = MaterialTheme.typography.headlineMedium
        )
        Spacer(modifier = Modifier.height(16.dp))
        MyText(
            text = "Vamos por buen camino",
            color = MaterialTheme.colorScheme.primary,
            style = MaterialTheme.typography.headlineSmall
        )
    }
}

@Composable
fun MyText(text: String, color: Color, style: TextStyle) {
    Text(text, color = color, style = style)
}

@Preview
@Composable
fun PreviewPersonalData() {
    PersonalData(name = "Luis Diego")
}

@Preview
@Preview(uiMode = Configuration.UI_MODE_NIGHT_YES)
@Composable
fun PreviewComponents() {
    AppTheme {
        MyComponent(itemText = "Aprendiendo sobre listas en JetPack Compose")
    }
}